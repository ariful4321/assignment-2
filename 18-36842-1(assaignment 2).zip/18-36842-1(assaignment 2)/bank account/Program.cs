﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace BankAccount
{
    public class Account
    {
        protected int AccountNumber;
        protected decimal Balance;
        protected AccountType Type;
        public AccountHolder AccountHolder;

        protected Account(AccountHolder accountHolder, int accountNumber, decimal balance)
        {
            AccountHolder = accountHolder;
            AccountNumber = accountNumber;
            Balance = balance;
        }

        public int GetAccountNumber()
        {
            return AccountNumber;
        }

        public decimal GetBalance()
        {
            return Balance;
        }

        public AccountType GetAccountType()
        {
            return Type;
        }

        public bool WithdrawFunds()
        {
            Console.Write($"Please confirm the amount you are taking out: ");
            string takingOut = Console.ReadLine();
            if (decimal.TryParse(takingOut, out decimal amount) && amount > 0)
            {
                if (Balance > amount)
                {
                    Balance = Balance - amount;
                    Console.WriteLine($"Withdrawal successful. Account balance is now {CultureInfo.CurrentCulture.NumberFormat.CurrencySymbol}{Balance}.");
                    Console.WriteLine();
                    AccountsSummary.AccountsDisplay(AccountHolder);
                    return true;
                }
                else
                {
                    Console.WriteLine("Insufficient funds.");
                    Console.WriteLine();
                    AccountsSummary.AccountsDisplay(AccountHolder);
                    return false;
                }

            }
            else
            {
                Console.WriteLine("Invalid input.");
                Console.WriteLine();
                AccountsSummary.AccountsDisplay(AccountHolder);
                return false;
            }
        }

        public bool WithdrawFunds(decimal withdrawalAmount)
        {
            if (Balance > withdrawalAmount && withdrawalAmount > 0)
            {
                Balance = Balance - withdrawalAmount;
                return true;
            }
            else
            {
                Console.WriteLine("Insufficient funds.");
                Console.WriteLine();
                AccountsSummary.AccountsDisplay(AccountHolder);
                return false;
            }
        }

        //handle negative deposit amounts
        public bool DepositFunds()
        {
            Console.Write($"Please confirm the amount you are paying in: ");
            string payingIn = Console.ReadLine();
            if (decimal.TryParse(payingIn, out decimal amount) && amount > 0)
            {
                Balance = Balance + amount;
                Console.WriteLine($"Deposit successful. Account balance is now: {CultureInfo.CurrentCulture.NumberFormat.CurrencySymbol}{Balance}.");
                Console.WriteLine();
                AccountsSummary.AccountsDisplay(AccountHolder);
                return true;
            }
            else
            {
                Console.WriteLine("Unable to process deposit. Please try again.");
                AccountsSummary.AccountsDisplay(AccountHolder);
                return false;
            }
        }

        public bool DepositFunds(decimal depositAmount)
        {
            if (depositAmount > 0)
            {
                Balance = Balance + depositAmount;
                return true;
            }

            else
            {
                Console.WriteLine("Unable to process deposit. Please try again.");
                AccountsSummary.AccountsDisplay(AccountHolder);
                return false;
            }

        }

        public bool TransferFunds()
        {
            Console.WriteLine("Available accounts to transfer to:");
            Console.WriteLine(AccountHolder.GetNonSelectedAccounts());
            Console.Write($"Please specify which account you want to transfer to? (1, 2, 3 etc.) ");
            string transferTo = Console.ReadLine();
            if (int.TryParse(transferTo, out int account))
            {
                Console.Write("How much would you like to transfer: ");
                var transferAmount = Console.ReadLine();
                if (decimal.TryParse(transferAmount, out decimal amount))
                {
                    AccountHolder.accounts.TryGetValue(account, out Account transferToAccount);
                    AccountHolder.CurrentlySelectedAccount().WithdrawFunds(amount);
                    transferToAccount.DepositFunds(amount);
                    Console.WriteLine("Transfer successful.");
                    Console.WriteLine($"{AccountHolder.CurrentlySelectedAccount().GetAccountType()} Account is now {CultureInfo.CurrentCulture.NumberFormat.CurrencySymbol}{AccountHolder.CurrentlySelectedAccount().Balance}.");
                    Console.WriteLine($"{transferToAccount.GetAccountType()} Account is now {CultureInfo.CurrentCulture.NumberFormat.CurrencySymbol}{transferToAccount.Balance}.");
                    AccountsSummary.AccountsDisplay(AccountHolder);
                    return true;
                }
                else
                {
                    Console.WriteLine("Invalid input.");
                    AccountsSummary.AccountsDisplay(AccountHolder);
                    return false;
                }

            }
            else
            {
                Console.WriteLine("Invalid account.");
                AccountsSummary.AccountsDisplay(AccountHolder);
                return false;
            }
        }

    }
}




>>

 

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace BankAccount
{
    public class AccountHolder
    {
        private string Name;
        private string Address;
        public Dictionary<int, Account> accounts = new Dictionary<int, Account>();
        private Account SelectedAccount;

        public AccountHolder(string name, string address)
        {
            Name = name;
            Address = address;
        }

        public string GetName()
        {
            return Name;
        }

        public string GetAddress()
        {
            return Address;
        }

        public void LinkAccountToHolder(Account account)
        {
            accounts.Add(accounts.Count + 1, account);
            if (accounts.Count == 1)
            {
                SelectedAccount = accounts[1];
            }
            else
            {
                SelectedAccount = CurrentlySelectedAccount();
            }
        }

        public void SelectAccount(AccountHolder accountHolder)
        {
            Console.WriteLine("Available accounts:");
            foreach (var account in accounts)
            {
                Console.WriteLine($"[{account.Key}] {account.Value.GetAccountType()} Account");
            }
            Console.Write($"Please specify which account you want to select? (1, 2, 3 etc.)");
            string selection = Console.ReadLine();
            if (int.TryParse(selection, out int accountSelection))
            {
                if (accounts.ContainsKey(accountSelection))
                {
                    Console.WriteLine($"Account {accountSelection} selected.");
                    SelectedAccount = accounts[accountSelection];
                    Console.WriteLine();
                    AccountsSummary.AccountsDisplay(accountHolder);
                }
                else
                {
                    Console.WriteLine("Invalid selection.");
                    Console.WriteLine();
                    AccountsSummary.AccountsDisplay(accountHolder);
                }
            }
            else
            {
                Console.WriteLine("Invalid selection.");
                AccountsSummary.AccountsDisplay(accountHolder);
            }
        }

        public Account CurrentlySelectedAccount()
        {
            return SelectedAccount;
        }

        public void ListAccounts()
        {
            foreach (var account in accounts)
            {
                if (account.Value.Equals(CurrentlySelectedAccount()))
                {
                    Console.WriteLine($"* [{account.Key}] {account.Value.GetAccountType()} Account        Balance: {CultureInfo.CurrentCulture.NumberFormat.CurrencySymbol}{account.Value.GetBalance()}");
                }
                else
                {
                    Console.WriteLine($"  [{account.Key}] {account.Value.GetAccountType()} Account        Balance: {CultureInfo.CurrentCulture.NumberFormat.CurrencySymbol}{account.Value.GetBalance()}");
                }
            }
        }

        public bool GetNonSelectedAccounts()
        {
            foreach (var account in accounts.Where(a => a.Value != CurrentlySelectedAccount()))
            {
                Console.WriteLine($"[{account.Key}] {account.Value.GetAccountType()} Account");
            }
            return true;
        }
    }
}


Explanation:
using System;
using System.Collections.Generic;
using System.Text;

namespace BankAccount
{
    class CurrentAccount : Account
    {

        public CurrentAccount(AccountHolder accountHolder, int accountNumber, decimal balance) : base(accountHolder, accountNumber, balance)
        {
            Type = AccountType.Current;
            AccountNumber = accountNumber;
            Balance = balance;
            AccountHolder = accountHolder;
        }
    }
}




>>

 

using System;
using System.Collections.Generic;

namespace BankAccount
{
    class Program
    {
        static void Main(string[] args)
        {
            AccountHolder RobsAccount = new AccountHolder("Rob", "Robs House, The Lane, Postcode, UK");
            CurrentAccount RobsCurrentAccount = new CurrentAccount(RobsAccount, 12345, 550);
            RobsAccount.LinkAccountToHolder(RobsCurrentAccount);
            SavingsAccount RobsSavingsAccount = new SavingsAccount(RobsAccount, 12346, 2200);
            RobsAccount.LinkAccountToHolder(RobsSavingsAccount);

            Console.WriteLine($"Hello {RobsAccount.GetName()}.");
            Console.WriteLine();
            AccountsSummary.AccountsDisplay(RobsAccount);
        }
    }
}




>>

 

using System;
using System.Collections.Generic;
using System.Text;

namespace BankAccount
{
    class SavingsAccount : Account
    {
        public SavingsAccount(AccountHolder accountHolder, int accountNumber, decimal balance) : base(accountHolder, accountNumber, balance)
        {
            Type = AccountType.Savings;
            AccountNumber = accountNumber;
            Balance = balance;
            AccountHolder = accountHolder;
        }
    }
}




>>

 

using System;
using System.Collections.Generic;
using System.Text;

namespace BankAccount
{
    public class AccountsSummary
    {
        /*commands available
         * q - exists application
         * l - lists accounts and balances
         * d - deposit
         * w - withdrawal
         * t - transfer
         * s - select account
        */

        public static void AccountsDisplay(AccountHolder accountHolder)
        {
            Console.WriteLine("Accounts");
            Console.WriteLine();
            Console.WriteLine("---------");
            Console.WriteLine();

            accountHolder.ListAccounts();

            Console.WriteLine();

            AccountCommands(accountHolder);
        }

        //TODO: Display currently selected account
        public static void AccountCommands(AccountHolder accountHolder)
        {
            Console.WriteLine("ENTER A COMMAND: [D]EPOSIT [W]ITHDRAW [T]RANSFER [S]ELECT ACCOUNT [L]IST ACCOUNTS [Q]UIT");
            string command = Console.ReadLine().ToUpper();
            switch (command)
            {
                case "D":
                    accountHolder.CurrentlySelectedAccount().DepositFunds();
                    break;
                case "W":
                    accountHolder.CurrentlySelectedAccount().WithdrawFunds();
                    break;
                case "T":
                    accountHolder.CurrentlySelectedAccount().TransferFunds();
                    break;
                case "S":
                    accountHolder.SelectAccount(accountHolder);
                    break;
                case "L":
                    accountHolder.ListAccounts();
                    break;
                case "Q":
                    Quit(accountHolder);
                    break;

                default:
                    Console.WriteLine("Invalid command.");
                    Console.WriteLine();
                    AccountCommands(accountHolder);
                    break;
            }
        }
        public static void Quit(AccountHolder accountHolder)
        {
            Console.WriteLine("Are you sure you want to quit? Y/N");
            string yesno = Console.ReadLine().ToUpper();

            if (yesno == "Y")
            {
                Environment.Exit(0);
            }
            else
            {
                AccountCommands(accountHolder);
            }
        }
    }
}
